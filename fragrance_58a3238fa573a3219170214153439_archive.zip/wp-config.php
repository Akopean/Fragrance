<?php
/**
 * Основные параметры WordPress.
 *
 * Скрипт для создания wp-config.php использует этот файл в процессе
 * установки. Необязательно использовать веб-интерфейс, можно
 * скопировать файл в "wp-config.php" и заполнить значения вручную.
 *
 * Этот файл содержит следующие параметры:
 *
 * * Настройки MySQL
 * * Секретные ключи
 * * Префикс таблиц базы данных
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** Параметры MySQL: Эту информацию можно получить у вашего хостинг-провайдера ** //
/** Имя базы данных для WordPress */
define('DB_NAME', 'fragrance');

/** Имя пользователя MySQL */
define('DB_USER', 'root');

/** Пароль к базе данных MySQL */
define('DB_PASSWORD', 'toor');

/** Имя сервера MySQL */
define('DB_HOST', 'localhost');

/** Кодировка базы данных для создания таблиц. */
define('DB_CHARSET', 'utf8mb4');

/** Схема сопоставления. Не меняйте, если не уверены. */
define('DB_COLLATE', '');

/**#@+
 * Уникальные ключи и соли для аутентификации.
 *
 * Смените значение каждой константы на уникальную фразу.
 * Можно сгенерировать их с помощью {@link https://api.wordpress.org/secret-key/1.1/salt/ сервиса ключей на WordPress.org}
 * Можно изменить их, чтобы сделать существующие файлы cookies недействительными. Пользователям потребуется авторизоваться снова.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         ' [P54UYvWVF0[LP.zl#/uu4Iu}c/7B2A-W/&cVilpEnO~{g[A#_m7-JZ;H`.QFm~');
define('SECURE_AUTH_KEY',  'BBsR6IC@OBg<M5uL0bfNqj0`Z::xCB0[9G0Y{FDo %3jW6Jg(@)]&zVG[=JDd2(f');
define('LOGGED_IN_KEY',    '&nKoi.dk_03[P&7Yn|~6b ^mhC}0}6!?R-TL$%ZdL:%u!,Pg7nt*:|H==14~+cA/');
define('NONCE_KEY',        'amWmmdVoNtQB2xGM.wU1aQ<g)+D-bSSUzX#P,=_Y7!p19GFmXONx@tjtd~iL{Fu+');
define('AUTH_SALT',        '3ugC|zO_3Id6u_8*Csb}@ eLiS;,kA@F!q~l}L#{%!c%Y/8+Fqv bGN~sqk:N~j.');
define('SECURE_AUTH_SALT', 'N0e_HZ=ce!z.6-h].1_[]bJN6b9ZF?:B>Cp}kI77 yIC4$6civ#MOnrMTuw@g)NK');
define('LOGGED_IN_SALT',   '[jnEJ!WLf`+@9I9giWUN`](O-!`N5U/V3:U8S*rFNJ)DBjL)[%]tEO`p+:2Z,&_d');
define('NONCE_SALT',       '#r[4J|*Wa]]0-^IE|V|+4A% 1VDy~ l}uGjBxzk2WMyk4@Z;#kE%}xz!NWxQicjp');

/**#@-*/

/**
 * Префикс таблиц в базе данных WordPress.
 *
 * Можно установить несколько сайтов в одну базу данных, если использовать
 * разные префиксы. Пожалуйста, указывайте только цифры, буквы и знак подчеркивания.
 */
$table_prefix  = 'wp_';

/**
 * Для разработчиков: Режим отладки WordPress.
 *
 * Измените это значение на true, чтобы включить отображение уведомлений при разработке.
 * Разработчикам плагинов и тем настоятельно рекомендуется использовать WP_DEBUG
 * в своём рабочем окружении.
 * 
 * Информацию о других отладочных константах можно найти в Кодексе.
 *
 * @link https://codex.wordpress.org/Debugging_in_WordPress
 */
define('WP_DEBUG', false);

/* Это всё, дальше не редактируем. Успехов! */

/** Абсолютный путь к директории WordPress. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** Инициализирует переменные WordPress и подключает файлы. */
require_once(ABSPATH . 'wp-settings.php');
